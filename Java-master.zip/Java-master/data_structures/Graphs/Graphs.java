
/**
 * This class implements the Graph data structure
 * using the classes Graph and Graphs.
 * 
 * @author Zachary Jones
 *
 */
class Graph {
	
}

/**
 * This class is used to test the Graph
 * class above.
 * 
 * @author Zachary Jones
 *
 */

public class Graphs {
	
	/**
	 * Main method
	 * 
	 * @param args Command line arguments
	 */
	public static void main(String args[]) {
		
	}
	
}
